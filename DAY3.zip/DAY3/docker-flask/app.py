from flask import Flask

app=Flask(__name__)

@app.route("/")
def wish():
    return "Hi from docker. Malvika's first docker hands on!"
app.run(port=5000, host='0.0.0.0')

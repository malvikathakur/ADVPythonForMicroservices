import requests, time
from random import random

url="http://localhost:8000/predict"

while True:
    response=requests.get(url)
    print(response.json())
    time.sleep(random())

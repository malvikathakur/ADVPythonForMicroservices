from fastapi import FastAPI
from prometheus_client import Counter, generate_latest
from prometheus_client import CONTENT_TYPE_LATEST
from starlette.responses import Response

app = FastAPI()

inference_counter = Counter("inference_requests", "Number of inference requests")

@app.get("/predict")
def predict():
    inference_counter.inc()
    return {"prediction": "positive"}

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

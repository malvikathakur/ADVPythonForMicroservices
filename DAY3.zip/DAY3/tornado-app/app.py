import tornado.ioloop
import tornado.web
from handlers import BooksHandler, BookHandler  # Import handlers

def make_app():
    return tornado.web.Application([
        (r"/books", BooksHandler),
        (r"/books/(\d+)", BookHandler),
    ])

if __name__ == "__main__":
    app = make_app()
    app.listen(8888)  # Runs Tornado server on port 8888
    print("Server running on http://localhost:8888")
    tornado.ioloop.IOLoop.current().start()

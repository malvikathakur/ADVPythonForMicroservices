import json
import tornado.web

# Sample data (in-memory database)
books = [
    {"id": 1, "title": "1984", "author": "George Orwell"},
    {"id": 2, "title": "To Kill a Mockingbird", "author": "Harper Lee"},
]

class BooksHandler(tornado.web.RequestHandler):
    def get(self):
        """Return all books"""
        self.set_header("Content-Type", "application/json")
        self.write(json.dumps(books))

    def post(self):
        """Add a new book"""
        try:
            data = json.loads(self.request.body)
            new_book = {
                "id": books[-1]["id"] + 1 if books else 1,
                "title": data["title"],
                "author": data["author"]
            }
            books.append(new_book)
            self.set_status(201)  # Created
            self.write(json.dumps(new_book))
        except Exception as e:
            self.set_status(400)  # Bad Request
            self.write({"error": str(e)})

class BookHandler(tornado.web.RequestHandler):
    def get(self, book_id):
        """Get a book by ID"""
        book = next((b for b in books if b["id"] == int(book_id)), None)
        if book:
            self.write(json.dumps(book))
        else:
            self.set_status(404)
            self.write({"error": "Book not found"})

    def put(self, book_id):
        """Update a book"""
        book = next((b for b in books if b["id"] == int(book_id)), None)
        if book:
            data = json.loads(self.request.body)
            book.update(data)
            self.write(json.dumps(book))
        else:
            self.set_status(404)
            self.write({"error": "Book not found"})

    def delete(self, book_id):
        """Delete a book"""
        global books
        books = [b for b in books if b["id"] != int(book_id)]
        self.set_status(204)  # No Content

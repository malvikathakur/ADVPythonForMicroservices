import os

class Config:
    # Flask secret key for sessions, signing cookies, etc.
    SECRET_KEY = os.environ.get("SECRET_KEY", "supersecretkey")

    # PostgreSQL connection string
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        "postgresql+psycopg2://user:userpassword@localhost:5432/mydb"
    )

    # Disable Flask-SQLAlchemy change tracking (uses more memory if True)
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # JWT secret key to sign tokens
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "jwt-secret-key")

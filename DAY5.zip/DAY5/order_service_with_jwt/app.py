from flask import Flask
from config import Config
from db import db
from flask_jwt_extended import JWTManager
from routes import bp  # Import blueprint

app = Flask(__name__)
app.config.from_object(Config)  # Load config from config.py

# Initialize extensions
db.init_app(app)
jwt = JWTManager(app)

# Register the route blueprint
app.register_blueprint(bp)

# Create all database tables at app startup
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)

import requests
from pprint import pprint

BASE_URL = "http://127.0.0.1:5000"

# 1. Login
print("Logging in")
auth_resp = requests.post(f"{BASE_URL}/login", json={
    "username": "admin",
    "password": "admin"
})
token = auth_resp.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}
print("Acquired token", token)

# 2. Create Order
print("Creating order")
order_resp = requests.post(f"{BASE_URL}/orders", json={
    "customer_name": "Rajat",
    "item": "Laptop",
    "quantity": 1
}, headers=headers)
print("Create Order:", order_resp.json())

print("Fetching orders")
# 3. Get Orders
orders_resp = requests.get(f"{BASE_URL}/orders", headers=headers)
for order in orders_resp.json():
    pprint(order)

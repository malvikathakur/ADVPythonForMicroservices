from flask_sqlalchemy import SQLAlchemy

# Create a SQLAlchemy instance that will be initialized in app.py
db = SQLAlchemy()

from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required
from models import Order
from db import db

# Blueprint groups routes under one namespace
bp = Blueprint('routes', __name__)

# ----------------------
# Dummy login endpoint
# ----------------------
@bp.route("/login", methods=["POST"])
def login():
    """
    Dummy user login that returns JWT if credentials match.
    """
    data = request.get_json()
    if data["username"] == "admin" and data["password"] == "admin":
        token = create_access_token(identity=data["username"])
        return jsonify(access_token=token)
    return jsonify(msg="Invalid credentials"), 401

# ----------------------
# Create Order
# ----------------------
@bp.route("/orders", methods=["POST"])
@jwt_required()  # Requires a valid JWT token
def create_order():
    """
    Creates a new order. Requires JWT token.
    """
    data = request.get_json()
    order = Order(
        customer_name=data["customer_name"],
        item=data["item"],
        quantity=data["quantity"]
    )
    db.session.add(order)
    db.session.commit()
    return jsonify({"id": order.id, "message": "Order created"}), 201

# ----------------------
# List Orders
# ----------------------
@bp.route("/orders", methods=["GET"])
@jwt_required()  # Requires a valid JWT token
def list_orders():
    """
    Lists all orders. Requires JWT token.
    """
    orders = Order.query.all()
    result = []
    for order in orders:
        result.append({
            "id": order.id,
            "customer_name": order.customer_name,
            "item": order.item,
            "quantity": order.quantity,
            "created_at": order.created_at.isoformat()
        })
    return jsonify(result)

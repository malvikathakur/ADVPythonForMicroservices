from flask import Flask, request, jsonify

app = Flask(__name__)
books = {}

@app.route("/books", methods=["GET"])
def get_books():
    return jsonify(list(books.values()))

@app.route("/books/<int:book_id>", methods=["GET"])
def get_book(book_id):
    return jsonify(books.get(book_id, {}))

@app.route("/books", methods=["POST"])
def create_book():
    data = request.get_json()
    book_id = data["id"]
    books[book_id] = data
    return jsonify(data), 201

@app.route("/books/<int:book_id>", methods=["PUT"])
def update_book(book_id):
    data = request.get_json()
    books[book_id] = data
    return jsonify(data)

@app.route("/books/<int:book_id>", methods=["DELETE"])
def delete_book(book_id):
    if book_id in books:
        del books[book_id]
    return '', 204

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

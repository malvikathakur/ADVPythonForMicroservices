import requests

KONG_PROXY = "http://localhost:8000/api/books"
API_KEY = "demo-key"

headers = {
    "apikey": API_KEY,
    "Content-Type": "application/json"
}

def test_create():
    r = requests.post(KONG_PROXY, headers=headers, json={"id": 1, "title": "Kong Book", "author": "API"})
    print("Create:", r.status_code, r.json())

def test_get_all():
    r = requests.get(KONG_PROXY, headers=headers)
    print("Get All:", r.status_code, r.json())

def test_get_one():
    r = requests.get(f"{KONG_PROXY}/1", headers=headers)
    print("Get One:", r.status_code, r.json())

def test_update():
    r = requests.put(f"{KONG_PROXY}/1", headers=headers, json={"id": 1, "title": "Updated", "author": "Kong"})
    print("Update:", r.status_code, r.json())

def test_delete():
    r = requests.delete(f"{KONG_PROXY}/1", headers=headers)
    print("Delete:", r.status_code)

if __name__ == "__main__":
    test_create()
    test_get_all()
    test_get_one()
    test_update()
    test_get_one()
    test_delete()

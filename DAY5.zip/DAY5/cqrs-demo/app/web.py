import time
from kafka import KafkaProducer
import psycopg2
from pymongo import MongoClient
from flask import Flask, request, redirect, render_template, jsonify
import json

app = Flask(__name__)

# PostgreSQL (write model)
def connect_postgres(retries=5):
    while retries > 0:
        try:
            conn = psycopg2.connect(
                host='postgres',
                dbname='cqrs',
                user='admin',
                password='admin'
            )
            conn.autocommit = True
            print("Connected to PostgreSQL")
            return conn
        except Exception as e:
            print(f"Waiting for PostgreSQL... ({e})")
            retries -= 1
            time.sleep(3)
    raise Exception("Could not connect to PostgreSQL")

# Kafka Producer
def connect_kafka(retries=5):
    while retries > 0:
        try:
            producer = KafkaProducer(
                bootstrap_servers='kafka:9092',
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
            print("Connected to Kafka")
            return producer
        except Exception as e:
            print(f"Waiting for Kafka... ({e})")
            retries -= 1
            time.sleep(3)
    raise Exception("Could not connect to Kafka")

# MongoDB (read model)
def connect_mongo(retries=5):
    while retries > 0:
        try:
            client = MongoClient('mongo', 27017)
            print("Connected to MongoDB")
            return client
        except Exception as e:
            print(f"Waiting for MongoDB... ({e})")
            retries -= 1
            time.sleep(3)
    raise Exception("Could not connect to MongoDB")

pg = connect_postgres()
cursor = pg.cursor()
producer = connect_kafka()
mongo = connect_mongo()
db = mongo.cqrs

@app.route('/')
def index():
    users = list(db.users.find({}, {'_id': 0}))
    return render_template('index.html', users=users)

@app.route('/api/users')
def index1():
    users = list(db.users.find({}, {'_id': 0}))
    return jsonify(users)

@app.route('/api/add', methods=['POST'])
def add_user1():
    name = request.json['name']
    email = request.json['email']
    cursor.execute("INSERT INTO users (name, email) VALUES (%s, %s)", (name, email))
    producer.send('user-events', {'name': name, 'email': email})
    return jsonify({'name': name, 'email': email}), 201


@app.route('/add', methods=['POST'])
def add_user():
    name = request.form['name']
    email = request.form['email']
    cursor.execute("INSERT INTO users (name, email) VALUES (%s, %s)", (name, email))
    producer.send('user-events', {'name': name, 'email': email})
    return redirect('/')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

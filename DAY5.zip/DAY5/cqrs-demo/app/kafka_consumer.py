import json
from kafka import KafkaConsumer
from pymongo import MongoClient

consumer = KafkaConsumer(
    'user-events',
    bootstrap_servers='kafka:9092',
    auto_offset_reset='earliest',
    group_id='read-model-updater',
    value_deserializer=lambda m: json.loads(m.decode('utf-8'))
)

mongo = MongoClient('mongo', 27017)
db = mongo.cqrs
db.users.delete_many({})

print("Kafka consumer listening...")

for message in consumer:
    user = message.value
    db.users.insert_one(user)
    print(f"Synced user to MongoDB: {user}")

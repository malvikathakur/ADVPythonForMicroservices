import time
from kafka import KafkaProducer
import psycopg2
from pymongo import MongoClient
from flask import Flask, request, redirect, render_template, jsonify
import json

app = Flask(__name__)

# PostgreSQL (write model)
def connect_postgres(retries=5):
    while retries > 0:
        try:
            conn = psycopg2.connect(
                host='postgres',
                dbname='cqrs',
                user='admin',
                password='admin'
            )
            conn.autocommit = True
            print("Connected to PostgreSQL")
            return conn
        except Exception as e:
            print(f"Waiting for PostgreSQL... ({e})")
            retries -= 1
            time.sleep(3)
    raise Exception("Could not connect to PostgreSQL")

# Kafka Producer
def connect_kafka(retries=5):
    while retries > 0:
        try:
            producer = KafkaProducer(
                bootstrap_servers='kafka:9092',
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
            print("Connected to Kafka")
            return producer
        except Exception as e:
            print(f"Waiting for Kafka... ({e})")
            retries -= 1
            time.sleep(3)
    raise Exception("Could not connect to Kafka")

# MongoDB (read model)
def connect_mongo(retries=5):
    while retries > 0:
        try:
            client = MongoClient('mongo', 27017)
            print("Connected to MongoDB")
            return client
        except Exception as e:
            print(f"Waiting for MongoDB... ({e})")
            retries -= 1
            time.sleep(3)
    raise Exception("Could not connect to MongoDB")

pg = connect_postgres()
cursor = pg.cursor()
producer = connect_kafka()
mongo = connect_mongo()
db = mongo.cqrs

@app.route('/')
def index():
    books = list(db.books.find({}, {'_id': 0}))
    return render_template('index.html', books=books)

@app.route('/api/books')
def index1():
    books = list(db.books.find({}, {'_id': 0}))
    return jsonify(books)

@app.route('/api/add', methods=['POST'])
def add_book1():
    name = request.json['name']
    author = request.json['author']
    cursor.execute("INSERT INTO books (name, author) VALUES (%s, %s)", (name, author))
    producer.send('user-events', {'name': name, 'author': author})
    return jsonify({'name': name, 'author': author}), 201


@app.route('/add', methods=['POST'])
def add_book():
    name = request.form['name']
    author = request.form['author']
    cursor.execute("INSERT INTO books (name, author) VALUES (%s, %s)", (name, author))
    producer.send('user-events', {'name': name, 'author': author})
    return redirect('/')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

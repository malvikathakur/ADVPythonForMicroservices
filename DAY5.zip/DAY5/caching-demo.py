import time
import redis
import os

# Constants
KEY = "test_key"
VALUE = "test_value"
NUM_TRIALS = 10000

# In-memory benchmark
def benchmark_inmemory():
    store = {}
    start = time.time()
    for _ in range(NUM_TRIALS):
        store[KEY] = VALUE
        _ = store[KEY]
    end = time.time()
    return end - start

# File I/O benchmark
def benchmark_fileio():
    filename = "temp_file.txt"
    start = time.time()
    for _ in range(NUM_TRIALS):
        with open(filename, "w") as f:
            f.write(VALUE)
        with open(filename, "r") as f:
            _ = f.read()
    end = time.time()
    os.remove(filename)
    return end - start

# Redis benchmark
def benchmark_redis():
    r = redis.Redis(host='localhost', port=6379, db=0)
    start = time.time()
    for _ in range(NUM_TRIALS):
        r.set(KEY, VALUE)
        _ = r.get(KEY)
    end = time.time()
    return end - start

# Main
if __name__ == "__main__":
    print(f"Running {NUM_TRIALS} trials...")

    mem_time = benchmark_inmemory()
    print(f"In-Memory time: {mem_time:.4f} seconds")

    file_time = benchmark_fileio()
    print(f"File I/O time: {file_time:.4f} seconds")

    redis_time = benchmark_redis()
    print(f"Redis time: {redis_time:.4f} seconds")

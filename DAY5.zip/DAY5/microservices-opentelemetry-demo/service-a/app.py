from flask import Flask, request
import requests
from telemetry import setup_telemetry

app = Flask(__name__)
setup_telemetry(service_name="service-a")

@app.route("/process")
def process():
    response = requests.get("http://service-b:5000/work")
    return f"Service A processed. Got: {response.text}"

if __name__ == "__main__":
    app.run(host="0.0.0.0")

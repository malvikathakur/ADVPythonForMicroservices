from flask import Flask
from telemetry import setup_telemetry

app = Flask(__name__)
setup_telemetry(service_name="service-b")

@app.route("/work")
def work():
    return "Work done by Service B"

if __name__ == "__main__":
    app.run(host="0.0.0.0")

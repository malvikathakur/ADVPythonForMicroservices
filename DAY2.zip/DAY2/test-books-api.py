import requests

BASE_URL = "http://127.0.0.1:8000/api/books"  # Replace with your actual API URL

def list_books():
    response = requests.get(BASE_URL)
    if response.status_code == 200:
        print("Books List:")
        for book in response.json():
            print(book)
    else:
        print("Failed to retrieve books:", response.status_code)

def get_book(book_id):
    response = requests.get(f"{BASE_URL}/{book_id}")
    if response.status_code == 200:
        print("Book Details:", response.json())
    else:
        print("Book not found:", response.status_code)

def create_book(title, author, year):
    data = {
        "title": title,
        "author": author,
        "year": year
    }
    response = requests.post(BASE_URL, json=data)
    if response.status_code in (200, 201):
        print("Book created successfully:", response.json())
    else:
        print("Failed to create book:", response.status_code, response.text)

def update_book(book_id, title=None, author=None, year=None):
    data = {}
    if title:
        data["title"] = title
    if author:
        data["author"] = author
    if year:
        data["year"] = year

    response = requests.put(f"{BASE_URL}/{book_id}", json=data)
    if response.status_code == 200:
        print("Book updated:", response.json())
    else:
        print("Failed to update book:", response.status_code, response.text)

def delete_book(book_id):
    response = requests.delete(f"{BASE_URL}/{book_id}")
    if response.status_code == 204:
        print("Book deleted successfully.")
    else:
        print("Failed to delete book:", response.status_code)

# Example Usage
if __name__ == "__main__":
    list_books()
    create_book("Wings of Fire", "Abdul Kalam", 1995)
    get_book(1)
    update_book(1, year=1999)
    delete_book(1)

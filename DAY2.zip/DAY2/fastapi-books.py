from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI()

# In-memory "database"
books_db = []
book_id_counter = 1

# Book schema
class Book(BaseModel):
    id: Optional[int] = None
    title: str
    author: str
    year: int

@app.get("/api/books", response_model=List[Book])
def list_books():
    return books_db

@app.get("/api/books/{book_id}", response_model=Book)
def get_book(book_id: int):
    for book in books_db:
        if book["id"] == book_id:
            return book
    raise HTTPException(status_code=404, detail="Book not found")

@app.post("/api/books", response_model=Book, status_code=201)
def create_book(book: Book):
    global book_id_counter
    book.id = book_id_counter
    books_db.append(book.dict())
    book_id_counter += 1
    return book

@app.put("/api/books/{book_id}", response_model=Book)
def update_book(book_id: int, updated_book: Book):
    for i, book in enumerate(books_db):
        if book["id"] == book_id:
            updated_data = updated_book.dict()
            updated_data["id"] = book_id
            books_db[i] = updated_data
            return updated_data
    raise HTTPException(status_code=404, detail="Book not found")

@app.delete("/api/books/{book_id}", status_code=204)
def delete_book(book_id: int):
    for i, book in enumerate(books_db):
        if book["id"] == book_id:
            books_db.pop(i)
            return
    raise HTTPException(status_code=404, detail="Book not found")

import os
import jwt
import datetime
from flask import Flask, request, jsonify, render_template
from functools import wraps

# Initialize Flask app
app = Flask(__name__)

# Secret key for JWT encoding/decoding
app.config['SECRET_KEY'] = 'mysecretkey'

# Dummy user data (In real-world apps, you'd have a database)
users = {
    'testuser': 'password123'
}

# Helper function to require authentication for protected routes
def token_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None
        
        # Check if the token is passed in the Authorization header
        if 'x-access-token' in request.headers:
            token = request.headers['x-access-token']
        
        # If no token is found, return an error
        if not token:
            return jsonify({'message': 'Token is missing!'}), 403
        
        try:
            # Decode the token using the secret key
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = data['user']
        except:
            return jsonify({'message': 'Token is invalid!'}), 403
        
        # Pass the current user to the route function
        return f(current_user, *args, **kwargs)
    
    return decorated_function

# Route to generate a JWT (Login)
@app.route('/login', methods=['POST'])
def login():
    auth = request.json
    
    username = auth.get('username')
    password = auth.get('password')
    
    # Check if username exists in the dummy user data
    if username in users and users[username] == password:
        # Create the JWT token
        token = jwt.encode({
            'user': username,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
        }, app.config['SECRET_KEY'], algorithm="HS256")
        
        return jsonify({'token': token})
    
    return jsonify({'message': 'Invalid credentials!'}), 401

# Route to access a protected resource (needs JWT)
@app.route('/protected')
@token_required
def protected(current_user):
    return jsonify({'message': f'Hello {current_user}, you have access to this protected route!'})

# Route to test if the app is working (index route)
@app.route('/')
def index():
    return render_template('jwt-index.html')

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, jsonify, request
from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

app = Flask(__name__)

# Set up MongoDB client and database
client = MongoClient("mongodb://localhost:27017/")  # Connect to MongoDB running on localhost
db = client.mydatabase  # Use your database name
collection = db.users  # Use your collection name

# Route to check if the app is working
@app.route('/')
def home():
    return "Flask API with MongoDB is working!"

# Route to create a new user
@app.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()  # Get the JSON data from the request

    # Validate data
    name = data.get('name')
    email = data.get('email')

    if not name or not email:
        return jsonify({"error": "Name and email are required"}), 400

    # Create a new user document
    new_user = {
        "name": name,
        "email": email
    }

    result = collection.insert_one(new_user)  # Insert the user into the MongoDB collection

    # Return the created user's ID (converting ObjectId to string for easier usage)
    return jsonify({"message": "User created", "user_id": str(result.inserted_id)}), 201

# Route to get all users
@app.route('/users', methods=['GET'])
def get_users():
    users = collection.find()  # Get all users from the collection
    users_list = [{"user_id": str(user["_id"]), "name": user["name"], "email": user["email"]} for user in users]
    return jsonify(users_list), 200

# Route to get a specific user by ID
@app.route('/users/<user_id>', methods=['GET'])
def get_user(user_id):
    try:
        # Convert the string user_id to ObjectId
        user = collection.find_one({"_id": ObjectId(user_id)})
    except Exception as e:
        return jsonify({"error": "Invalid user ID format"}), 400

    if not user:
        return jsonify({"error": "User not found"}), 404

    # Return user data, converting _id to a string
    return jsonify({"user_id": str(user["_id"]), "name": user["name"], "email": user["email"]}), 200

# Route to update a user's information
@app.route('/users/<user_id>', methods=['PUT'])
def update_user(user_id):
    data = request.get_json()  # Get the JSON data from the request
    try:
        # Convert the string user_id to ObjectId
        user = collection.find_one({"_id": ObjectId(user_id)})
    except Exception as e:
        return jsonify({"error": "Invalid user ID format"}), 400

    if not user:
        return jsonify({"error": "User not found"}), 404

    # Update user data (name or email)
    name = data.get('name')
    email = data.get('email')

    update_data = {}
    if name:
        update_data["name"] = name
    if email:
        update_data["email"] = email

    collection.update_one({"_id": ObjectId(user_id)}, {"$set": update_data})

    return jsonify({"message": "User updated successfully"}), 200

# Route to delete a user by ID
@app.route('/users/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    try:
        # Convert the string user_id to ObjectId
        result = collection.delete_one({"_id": ObjectId(user_id)})
    except Exception as e:
        return jsonify({"error": "Invalid user ID format"}), 400

    if result.deleted_count == 0:
        return jsonify({"error": "User not found"}), 404

    return jsonify({"message": "User deleted successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)

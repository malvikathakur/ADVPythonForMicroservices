import grpc
from concurrent import futures
import time
import user_service_pb2
import user_service_pb2_grpc

class UserService(user_service_pb2_grpc.UserServiceServicer):
    def __init__(self):
        self.users = {}

    def CreateUser(self, request, context):
        user_id = str(len(self.users) + 1)  # Simple ID generation
        self.users[user_id] = {'name': request.name, 'email': request.email}
        return user_service_pb2.CreateUserResponse(user_id=user_id)

    def GetUser(self, request, context):
        user = self.users.get(request.user_id)
        if not user:
            context.set_details(f"User {request.user_id} not found")
            context.set_code(grpc.StatusCode.NOT_FOUND)
            return user_service_pb2.GetUserResponse()

        return user_service_pb2.GetUserResponse(
            user_id=request.user_id,
            name=user["name"],
            email=user["email"]
        )

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    user_service_pb2_grpc.add_UserServiceServicer_to_server(UserService(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("gRPC Server running on port 50051...")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        server.stop(0)

if __name__ == '__main__':
    serve()

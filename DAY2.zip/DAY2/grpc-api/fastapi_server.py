from fastapi import FastAPI
from pydantic import BaseModel
import grpc
import user_service_pb2
import user_service_pb2_grpc

app = FastAPI()

# gRPC client setup
channel = grpc.insecure_channel('localhost:50051')
stub = user_service_pb2_grpc.UserServiceStub(channel)

class CreateUserRequest(BaseModel):
    name: str
    email: str

class GetUserRequest(BaseModel):
    user_id: str

@app.post("/users/")
async def create_user(request: CreateUserRequest):
    grpc_request = user_service_pb2.CreateUserRequest(
        name=request.name,
        email=request.email
    )
    grpc_response = stub.CreateUser(grpc_request)
    return {"user_id": grpc_response.user_id}

@app.get("/users/{user_id}")
async def get_user(user_id: str):
    grpc_request = user_service_pb2.GetUserRequest(user_id=user_id)
    grpc_response = stub.GetUser(grpc_request)
    if grpc_response.user_id == "":
        return {"error": "User not found"}
    return {"user_id": grpc_response.user_id, "name": grpc_response.name, "email": grpc_response.email}

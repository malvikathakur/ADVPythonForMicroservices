from flask import Flask, jsonify, request

app = Flask(__name__)

# In-memory data store (dictionary)
users = {}

# Route to check if the app is working
@app.route('/')
def home():
    return "Flask API with In-Memory User Store is working!"

# Route to create a new user
@app.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()  # Get the JSON data from the request
    
    # Validate data
    name = data.get('name')
    email = data.get('email')
    
    if not name or not email:
        return jsonify({"error": "Name and email are required"}), 400

    # Generate a unique user ID (this is just a simple counter for example purposes)
    user_id = str(len(users) + 1)
    
    # Create a new user and store it in the dictionary
    users[user_id] = {"name": name, "email": email}

    return jsonify({"message": "User created", "user_id": user_id}), 201

# Route to get all users
@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users), 200

# Route to get a specific user by ID
@app.route('/users/<user_id>', methods=['GET'])
def get_user(user_id):
    user = users.get(user_id)
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    return jsonify({user_id: user}), 200

# Route to update a user's information
@app.route('/users/<user_id>', methods=['PUT'])
def update_user(user_id):
    data = request.get_json()  # Get JSON data from the request
    user = users.get(user_id)
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Update user data
    name = data.get('name')
    email = data.get('email')

    if name:
        user['name'] = name
    if email:
        user['email'] = email
    
    return jsonify({"message": "User updated successfully"}), 200

# Route to delete a user by ID
@app.route('/users/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    user = users.pop(user_id, None)
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    return jsonify({"message": "User deleted successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)

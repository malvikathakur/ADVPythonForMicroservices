from fastapi import FastAPI,Request
import httpx

app=FastAPI()

USER_SERVICE_URL = "http://localhost:8001"
ORDER_SERVICE_URL = "http://localhost:8002"
INVOICE_SERVICE_URL = "http://localhost:8003"

client = httpx.AsyncClient()

@app.get("/users/{user_id}")
async def get_user(user_id: int):
    response = await client.get(f"{USER_SERVICE_URL}/users/{user_id}")
    return response.json()

@app.get("/orders/{order_id}")
async def get_order(order_id: int):
    response = await client.get(f"{ORDER_SERVICE_URL}/orders/{order_id}")
    return response.json()

@app.get("/invoice/{invoice_id}")
async def get_invoice(invoice_id: int):
    response = await client.get(f"{INVOICE_SERVICE_URL}/invoice/{invoice_id}")
    return response.json()

from fastapi import FastAPI

app = FastAPI()

@app.get("/invoice/{invoice_id}")
def read_invoice(invoice_id: int):
    return {"invoice_id": invoice_id, "item": "Laptop", "price":"$1000"}

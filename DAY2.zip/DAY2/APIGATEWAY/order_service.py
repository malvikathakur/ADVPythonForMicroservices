
from fastapi import FastAPI

app = FastAPI()

@app.get("/orders/{order_id}")
def read_order(order_id: int):
    return {"order_id": order_id, "item": "Laptop"}

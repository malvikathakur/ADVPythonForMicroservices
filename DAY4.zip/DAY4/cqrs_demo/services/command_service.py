from models.write_model import SessionLocal, UserWriteModel
from models.read_model import user_collection
import asyncio

def create_user(name: str, email: str):
    db = SessionLocal()
    user = UserWriteModel(name=name, email=email)
    db.add(user)
    db.commit()
    db.refresh(user)

    # Simulate syncing to MongoDB read model (in real apps, use event handler or outbox pattern)
    asyncio.run(sync_to_mongo(user))

    return user

async def sync_to_mongo(user):
    await user_collection.insert_one({
        "id": user.id,
        "name": user.name,
        "email": user.email
    })

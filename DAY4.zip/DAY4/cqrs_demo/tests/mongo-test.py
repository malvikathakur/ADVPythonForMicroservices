from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

try:
    client = MongoClient("mongodb://localhost:27017", serverSelectionTimeoutMS=3000)
    client.admin.command("ping")
    print("Connected to MongoDB")
    print("MongoDB databases:", client.list_database_names())
    client.close()

except ConnectionFailure as e:
    print(f"MongoDB connection error: {e}")

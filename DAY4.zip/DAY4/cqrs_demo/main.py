from fastapi import FastAPI
from services.command_service import create_user
from services.query_service import get_user_by_email
from pydantic import BaseModel

app = FastAPI()

class UserCreate(BaseModel):
    name: str
    email: str

@app.post("/users")
def create(user: UserCreate):
    return create_user(user.name, user.email)

@app.get("/users")
async def read_user(email: str):
    user = await get_user_by_email(email)
    return user or {"error": "User not found"}

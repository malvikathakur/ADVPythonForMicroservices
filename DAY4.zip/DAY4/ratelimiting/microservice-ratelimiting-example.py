from fastapi import FastAPI, Request, HTTPException
import redis
import time

app = FastAPI()

# Connect to Redis
redis_client = redis.Redis(host='localhost', port=6379, db=0)

# Rate limit config
RATE_LIMIT = 100  # requests
WINDOW_SIZE = 60  # seconds

def get_client_ip(request: Request) -> str:
    return request.client.host

@app.middleware("http")
async def rate_limiter(request: Request, call_next):
    client_ip = get_client_ip(request)
    current_window = int(time.time()) // WINDOW_SIZE

    key = f"rate_limit:{client_ip}:{current_window}"

    # Increment request count
    try:
        requests = redis_client.incr(key)
        if requests == 1:
            redis_client.expire(key, WINDOW_SIZE)
    except Exception as e:
        print(f"Redis error: {e}")
        requests = 1  # fallback

    if requests > RATE_LIMIT:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    response = await call_next(request)
    return response

@app.get("/")
async def home():
    return {"message": "Welcome! You're within the rate limit."}

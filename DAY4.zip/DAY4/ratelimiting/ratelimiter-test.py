import requests

for i in range(1, 106):
    response = requests.get("http://127.0.0.1:8000/")
    print(f"{i}: {response.text}")

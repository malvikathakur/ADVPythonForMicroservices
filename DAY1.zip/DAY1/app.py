import requests 
from rich.console import Console 
from rich.panel import Panel 
 
console = Console() 
 
def fetch_joke(): 
    url = "https://official-joke-api.appspot.com/random_joke" 
    try: 
        response = requests.get(url) 
        response.raise_for_status() 
        joke = response.json() 
        return f"{joke['setup']}\n\n{joke['punchline']}" 
    except requests.RequestException as e: 
        return f"Failed to fetch joke: {e}" 
 
def main(): 
    console.print(Panel("Fetching a random joke...", style="bold blue")) 
    joke = fetch_joke() 
    console.print(Panel(joke, title="Here's a Joke", style="green")) 
 
if __name__ == "__main__": 
    main() 


import psycopg2
from psycopg2 import OperationalError

try:
    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        user="user",
        password="userpassword",
        dbname="mydb"
    )
    print("Connected to PostgreSQL database")
    cursor = conn.cursor()
    cursor.execute("SELECT version();")
    version = cursor.fetchone()
    print(f"PostgreSQL version: {version[0]}")
    cursor.close()
    conn.close()

except OperationalError as e:
    print(f"PostgreSQL connection error: {e}")

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import sessionmaker

# Replace with your actual PostgreSQL credentials
DATABASE_URL = "postgresql://user:userpassword@localhost/mydb"

# Create an engine that will interact with PostgreSQL
engine = create_engine(DATABASE_URL)

# Create a base class for declarative models
Base = declarative_base()

# Define a model for a simple table called "User"
class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False, unique=True)

    def __repr__(self):
        return f"<User(name={self.name}, email={self.email})>"

# Create all the tables in the database (if they don't exist already)
Base.metadata.create_all(engine)

# Create a sessionmaker object
Session = sessionmaker(bind=engine)

# Create a session to interact with the database
session = Session()

# Example: Add a new user to the database
new_user = User(name="Kavita", email="kavi@example.com")
session.add(new_user)
session.commit()

# Query all users
users = session.query(User).all()
print(users)

# Close the session
session.close()

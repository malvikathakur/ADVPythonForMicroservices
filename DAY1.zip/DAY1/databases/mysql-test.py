import mysql.connector
from mysql.connector import Error

try:
    conn = mysql.connector.connect(
        host='localhost',
        port=3306,
        user='user',
        password='userpassword',
        database='mydb'
    )

    if conn.is_connected():
        print("Connected to MySQL database")
        cursor = conn.cursor()
        cursor.execute("SELECT VERSION()")
        version = cursor.fetchone()
        print(f"MySQL version: {version[0]}")
        cursor.close()
    conn.close()

except Error as e:
    print(f"MySQL connection error: {e}")

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import sessionmaker

# Replace with your actual PostgreSQL credentials
DATABASE_URL = "postgresql://user:userpassword@localhost/mydb"

# Create an engine that will interact with PostgreSQL
engine = create_engine(DATABASE_URL)

# Create a base class for declarative models
Base = declarative_base()

# Define a model for a simple table called "User"
class Book(Base):
    __tablename__ = 'books'

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String, nullable=False, unique=True)
    author = Column(String, nullable=False)

    def __repr__(self):
        return f"<Book(title={self.title}, author={self.author})>"

# Create all the tables in the database (if they don't exist already)
Base.metadata.create_all(engine)

# Create a sessionmaker object
Session = sessionmaker(bind=engine)

# Create a session to interact with the database
session = Session()

# Example: Add a new book to the database
new_book = Book(title="The Psychology of Money", author="Morgan Housel")
session.add(new_book)
session.commit()

# Query all books
books = session.query(Book).all()
print(books)

# Close the session
session.close()

import redis

try:
    r = redis.Redis(host='localhost', port=6379, db=0)
    r.ping()
    print("Connected to Redis")
    r.set("test_key", "test_value")
    value = r.get("test_key")
    print(f"Redis test_key value: {value.decode()}")
except redis.ConnectionError as e:
    print(f"Redis connection error: {e}")

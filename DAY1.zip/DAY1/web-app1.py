from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def hi():
    return "Hello from flask"

@app.route("/contact")
def hello():
    return "You can reach me on 4567898734"

@app.route("/weather")
def abc():
    return jsonify({"temperature":40,"rainfall":2}), 200 

app.run()
